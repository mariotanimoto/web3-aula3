const jwt = require('jsonwebtoken');

const autenticar = (req, res, next) => {
    const header = req.headers.authorization;
    if (!header?.startsWith('Bearer ')) return res.status(401).json({ error: 'Autenticação necessária.' });

    try {
        req.usuario = jwt.verify(header.slice(7), process.env.JWT_SECRET);
        next();
    } catch {
        return res.status(401).json({ error: 'Token inválido ou expirado.' });
    }
};

module.exports = { autenticar };
